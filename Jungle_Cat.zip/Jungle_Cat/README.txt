JUNGLE CAT
==========
RUN:      double-click start_game.bat (Windows) or run ./start_game.sh (Mac/Linux), then open http://localhost:8000
          (index.html alone also works by double-click; the music/sounds are then read from audio/audio_fallback.js)

FILES
  index.html        the page            css/style.css   the look of the menus
  js/game.js        the whole game      graphics/       all pictures (WebP)
  audio/            sounds (mono MP3, 24 kbit/s) + music.mod (music) + audio_fallback.js (same sounds as text, for double-click use)

CHANGE THE GAME
  Open js/game.js - everything you may want to change is at the very top in the block "GAME SETTINGS":
  speeds, hit points, jump lengths, shooting times, sizes of animations, sound volumes ... every line has a comment.
  Examples:  ARC_IDLE_LOOPS (idle loops of the enemy 10 archer before every shot)   GOR_JMIN / GOR_JMAX (gorilla jump length in metres)
             HANG_K (size of the hang-on-vine animation)   HID_STEP / HID_FADE (hero idle)   CAP_* (scene behind the end boss)
             CHEAT_KEYS = 0 switches the test keys off.
  Level data (LV) is one long line on purpose: [kind, x, patrol-from, patrol-to, ground-y]  (kinds are listed at the top of the file).

EXPERT SETTINGS IN THE GAME
  Title screen > SETTINGS > GRAPHICS > EXPERT SETTINGS: every number of the settings block as a list (about 240).
  UP / DOWN = choose   LEFT / RIGHT = change (SHIFT = 10 times bigger steps)   ENTER = back to default (last line = reset all)   ESC = back.
  Changes are saved in the browser; some values only take full effect after a page reload (F5).
  A new setting appears in this list only if you add a line to the TUNE list in js/game.js (right below the settings block).

CHANGE PICTURES / SOUNDS
  Replace a file with the same name and the same size. Pictures are WebP (quality ~85). Sounds: if you replace an MP3 in audio/,
  the double-click version needs audio/audio_fallback.js rebuilt (base64 of every sound in a JS object window.JC_AUDIO).

TEST KEYS (CHEAT_KEYS = 1):  5 in front of an enemy 10 archer   8 next to an enemy 30 archer   7 end boss   6 chimp   0 skeleton bridge   9 skip dance
